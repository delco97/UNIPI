load "docteur.ml";;
#open "docteur";;
print_string "Pour lancer: cam�lia();;"; print_newline();;
