include "fib";;
include "sieve";;
include "wc";;
print_string "To run:
        fib <some number>;;
        sieve <upper bound>;;
        count \"file name\";;";
print_newline();;

