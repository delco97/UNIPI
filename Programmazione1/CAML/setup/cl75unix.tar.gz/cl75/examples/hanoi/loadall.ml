load "hanoi.ml";;
#open "hanoi";;
print_string "Pour lancer: jeu <nombre de disques>;;"; print_newline();;
