load "showsort";;
#open "showsort";;
print_string "To run: animate();;"; print_newline();;
