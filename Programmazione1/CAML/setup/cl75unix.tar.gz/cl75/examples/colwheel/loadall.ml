load "colwheel.ml";;
#open "colwheel";;
print_string "To run: main();;"; print_newline();;
