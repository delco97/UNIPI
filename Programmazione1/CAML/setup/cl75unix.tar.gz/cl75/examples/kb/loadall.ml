load "prelude.ml";;
load "terms.ml";;
load "equation.ml";;
load "order.ml";;
load "kb.ml";;
load "go.ml";;
