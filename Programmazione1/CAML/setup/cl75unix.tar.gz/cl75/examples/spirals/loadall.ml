load "spir";;
#open "spir";;
print_string "To run: spir();;"; print_newline();;
