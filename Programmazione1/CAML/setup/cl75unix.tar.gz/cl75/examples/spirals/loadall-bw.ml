load "spir-bw";;
#open "spir-bw";;
print_string "To run: spir();;"; print_newline();;
