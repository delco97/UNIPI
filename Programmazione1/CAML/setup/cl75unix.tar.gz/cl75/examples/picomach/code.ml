let nombre_de_registres = 32
and sp = 30
and ra = 31
and taille_du_mot = 4;;
