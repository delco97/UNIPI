(* Generic comparisons *)

let min x y = if x <= y then x else y;;
let max x y = if x >= y then x else y;;
