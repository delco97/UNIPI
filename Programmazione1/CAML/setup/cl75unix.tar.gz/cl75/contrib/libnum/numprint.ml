#open "toplevel";;

install_printer "nat__print_nat";;
install_printer "big_int__print_big_int";;
install_printer "ratio__print_ratio";;
install_printer "num__print_num";;
