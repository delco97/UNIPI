let contained x y w =
  w = containing x y
;;
