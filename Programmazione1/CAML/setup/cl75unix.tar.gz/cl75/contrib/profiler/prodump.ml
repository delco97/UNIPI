(* magic *)
io__exit 0;;
