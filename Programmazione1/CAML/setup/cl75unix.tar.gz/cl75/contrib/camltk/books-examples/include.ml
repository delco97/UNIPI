(* Include all examples *)

include"ouster-s2.3";;

include"ouster-f2.2";;

(* include"ouster-f2.3";; requires unix *)

include"ouster-f16.1";;
include"ouster-f16.2";;
include"ouster-f16.3";;
include"ouster-f16.6";;
include"ouster-f16.7";;
include"ouster-f16.8";;
include"ouster-f16.9";;
include"ouster-f16.10";;
include"ouster-f16.11";;
include"ouster-f16.12";;
include"ouster-f16.13";;
include"ouster-f16.14";;
include"ouster-f16.15";;
include"ouster-f17.3";;
include"ouster-f17.4";;
include"ouster-f17.5";;
