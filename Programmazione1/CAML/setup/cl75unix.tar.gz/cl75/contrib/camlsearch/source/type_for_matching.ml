let Unit =
  {P_constant = [];
   P_frozen_variable = [];
   P_subst_variable = [];
   P_arity=0};;

let Unit_cost = 2;;
